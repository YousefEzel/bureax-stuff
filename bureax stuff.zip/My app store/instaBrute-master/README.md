# InstaBrute
<p align="center"><img src="http://forums.windowscentral.com/attachments/instagram/50396d1385186440t-947316_143336859186012_2088783896_n.png"</img></p>
## Description

Instagram bruteforce exploit module

## Usage

Usage: instaBrute -h

## Dependencies

1. Mechanize
2. CookieLib
3. Simplejson
4. OptParse
5. Selenium

## Example

```python
	python instaBrute.py -f usernames.txt -d dictionary.txt
```
```python
	python instaBrute.py -u facebook -d dictionary.txt
```	
## Features

1. Check username existence
2. Check password for a given username
3. Brute forcer mother fuckers!

## Special Thanks

[@camicelli!](http://twitter.com/camicelli)

Gabriel Rezzonico
