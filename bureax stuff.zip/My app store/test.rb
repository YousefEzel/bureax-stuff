#!/usr/bin/ruby
# 
# The ##title## with version 
# 
#
# Description:
#  
# CUPP 3.1.0-alpha => Common User Passwords Profiler made in PYTHON programming language to find nsome specific 
#     passwords about the victime depending on descriptions you give to the program in your hand :)
#
# Imad'Ox's Facebook Cracker TooL is a password cracking tool written in perl to perform adictionary-based 
#     attack on a specific Facebook user through HTTPS.
#
# The_Holder V1.0.1 made by The_Black_Cat in Ruby programming language to Hold on all those Two programs
#     to simple the using of them for you also it's come with a password security to be sure that only 
#     you, who you can access to your information and your hacked users :) 
#
####################################################
##  be free to use it as you wish                  #
##      also I'm not responsible of your problems  #
####################################################
#
# Usage:
# You just answer the qustions and you will be Fine :) 
# login must be your ID 
#
# Module Requirements:
#
#
# --- descripted tool
# --- By Black Cat XIII


begin
#colors changer 
class String
def black;          "\e[30m#{self}\e[0m" end
def red;            "\e[31m#{self}\e[0m" end
def green;          "\e[32m#{self}\e[0m" end
def brown;          "\e[33m#{self}\e[0m" end
def blue;           "\e[34m#{self}\e[0m" end
def magenta;        "\e[35m#{self}\e[0m" end
def cyan;           "\e[36m#{self}\e[0m" end
def gray;           "\e[37m#{self}\e[0m" end

def bg_black;       "\e[30m#{self}\e[0m" end
def bg_red;         "\e[41m#{self}\e[0m" end
def bg_green;       "\e[42m#{self}\e[0m" end
def bg_brown;       "\e[43m#{self}\e[0m" end
def bg_blue;        "\e[44m#{self}\e[0m" end
def bg_magenta;     "\e[45m#{self}\e[0m" end
def bg_cyan;        "\e[46m#{self}\e[0m" end
def bg_gray;        "\e[47m#{self}\e[0m" end

def bold;           "\e[1m#{self}\e[22m" end
def italic;         "\e[3m#{self}\e[23m" end
def underline;      "\e[4m#{self}\e[24m" end
def blink;          "\e[5m#{self}\e[25m" end
def reverse_color;  "\e[7m#{self}\e[27m" end
end

#Error loader
begin
  require 'io/console'
rescue LoadError
end

##Passwd Hider
if STDIN.respond_to?(:noecho)
  def get_password(prompt="Password: ")
    print prompt
    STDIN.noecho(&:gets).chomp
  end
else
  def get_password(prompt="Password: ")
    `read -s -p "#{prompt}" password; echo $password`.chomp
  end
end

#var to change colors and bgs
a = "+-------------------+".bg_blue.bold.italic
b = "|   Tiiiiiiiiitle   |".bg_blue.bold.italic
c = "+-------------------+".bg_blue.bold.italic
d = "+--------------------------------------+".bg_blue.bold.italic
e = "| ".bg_green
f = "|           ".bg_green
name = " Youssef MHAMDI ".bg_red.bold
cod = "|          Coded By : ".bg_green

#Graphizme
print "          "+"/------------------------------------------/""\n".bg_green
print "          "+"#{f}"+"#{a}"+"          |""\n".bg_green
print "          "+"#{f}"+"#{b}"+"          |""\n".bg_green
print "          "+"#{f}"+"#{c}"+"          |""\n".bg_green
print "          "+"#{e}"+"#{d}"+" |""\n".bg_green
print "          "+"|           Welcome Login System           |""\n".bg_green
print "          "+"|   ------------------------------------   |""\n".bg_green
print "          "+"|       Please Enter Your Information      |""\n".bg_green
print "          "+"|      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^     |""\n".bg_green
print "          "+"#{cod}"+"#{name}"+"     |""\n".bg_green
print "          "+"|        ¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨     |""\n".bg_green
print "          "+"|    www.facebook.com/yousef.mhamdi.007    |""\n".bg_green.bold
print "          "+"|   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^   |""\n".bg_green
print "          "+"/------------------------------------------/""\n".bg_green

puts "\n\n"
version = "'The_Holder V1.0.1'".bg_brown
print "       The Version of the Program is #{version}\n\n"


## Informations ID
print "    Your Idendity Please : "
id = gets.chomp
ids = id.bg_green

@password = get_password("    Enter Your Password Here: ")
puts "\n"
#Clear
system("clear")

wm = "|       Welcome Mr ".bg_blue
esp = "     |".bg_blue
w = "    ".bg_cyan
co = "|         (__)".bg_blue


if  @password == "" && id == "black cat"
############################################ N° FORM  ######################################
print "________________________________________________________________________________ \n" 
print "|                                                                              |\n"
print "|                          I love Security and Haking.                         |\n"
print "|______________________________________________________________________________|\n"
print "|                                                                              |\n"
print "|                                                                              |\n"
print "|                                                                              |\n"
print "|                 User Name:          [   #{ids}  ]                         |\n"
print "|                                                                              |\n"
print "|                 Password:           [   *********  ]                         |\n"
print "|                                                                              |\n"
print "|    My facebook: www.facebook.com/yousef.mhamdi.007                           |\n"
print "|                                                                              |\n" 
print "|    My instagram: www.instagram.com/royal-hack-tkd                            |\n"
print "|                                                                              |\n"
print "|    My Operating System [OS]  => Kali linux                                   |\n"
print "|                                                                              |\n"
print "|                                   [ OK ]                                     |\n"
print "|______________________________________________________________________________|\n"
print "|                                                                              |\n"
print "|                             Script by Black_Cat                              |\n"
print "|                              Version: 1.0                                    |\n"
print "|                       Script Location : ./test.rb                            |\n"
print "|--------------Connection Info :-----------------------------------------------|\n"
print "|        -- Gateway: 10.7.20.1 Interface: wlan0 My LAN Ip: 10.7.20.51          |\n"
print "|                                                                              |\n"
print "|______________________________________________________________________________|\n"
print "|                                     |                                        |\n"
print "|  1- Update/upgrade Kali Linux       |     5- Generate a Password file        |\n"
print "|  2- fb/insta brute-force Tools      |     6- Must View                       |\n"
print "|  3- Install Hacking Tools           |     7- EXIT PROGRAM           ________ |\n"
print "|  4- Install xxxxxxxxxxxxxxxx        |                               |_XIII_| |\n"
print "|_____________________________________|________________________________________|\n"

else
        print "\n"+"              "+"  ¡ Access Denied Mr #{ids} ! \n".bg_red.bold
        system(exit)

end
print "\n"
############## Conditions #############
print "    Choose a N° : "
num = gets.chomp

if num == '1'
	print " -1- Update or  -2- Upgrade or -3- dist-upgrade : "
	up = gets.chomp
	if up == '1' 
	system("apt-get update")
	elsif up == '2'
	system("apt-get upgrade")
	elsif up == '3' 
	system ("apt-get dist-upgrade")
elsif num == '2'
	puts " -1- face-brute or -2- insta-brute "
	print " what do you need : "
	needs = gets.chomp
	if needs == ''
	system("git clone ")

elsif num == '2'


elsif num == '2'

elsif num == '2'


elsif num == '2'


elsif num == '2'



end
end
#1 update or upgrade
#2 install brute force tool ( face.perl - cupp - crunch - hydra - instagram brute forcer - the holder v1.0 - lazykali - Ddosv1.0 )
